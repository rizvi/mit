<?php

	$expire=time()+60*60*24*3;
	setcookie("Cookie_Name", "Cookie_Value", $expire); 


 ?>
