<html>
<head>
<title> php form processing </title>
</head>
<body>

<?php
echo "First Name:" . $_REQUEST["firstName"] . "<br>";
echo "Last Name:" . $_REQUEST["lastName"] ; 
?>

<body>
</html>

