<html>
<head>
<title> php form processing </title>
</head>
<body>

<?php
echo "First Name:" . $_GET["firstName"] . "<br>";
echo "Last Name:" . $_GET["lastName"] ; 
?>

<body>
</html>

